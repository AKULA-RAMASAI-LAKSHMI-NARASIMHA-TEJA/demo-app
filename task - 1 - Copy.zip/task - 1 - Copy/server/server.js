const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const path = require('path');
const authRoutes = require('./routes/login.js');

const app = express();
const PORT = 4000;

const corsOptions = {
  origin: 'http://localhost:4200', 
  methods: 'GET,POST,PUT,DELETE',  
  credentials: true,  
};

app.use(cors(corsOptions));  

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());  

mongoose
  .connect('mongodb://127.0.0.1:27017/login', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to MongoDB'))
  .catch((err) => console.error('Error connecting to MongoDB:', err));

app.use(authRoutes);

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
