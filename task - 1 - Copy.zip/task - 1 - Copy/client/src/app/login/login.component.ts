import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, HttpClientModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent {
  username: string = '';
  password: string = '';

  constructor(private http: HttpClient, private router: Router) {}

  onLogin() {
    // Login data
    const loginData = { username: this.username, password: this.password };

    // Send a POST request to the backend (login route)
    this.http.post('http://localhost:4000/login', loginData).subscribe(
      (response: any) => {
        console.log(response);

        if (response && response.message === 'Login successful') {
          alert('Login Successful');
          this.router.navigate(['home']); // Redirect to 'home' page on success
        } else {
          alert('Unexpected response from the server.');
        }
      },
      (error: any) => {
        console.error('Login error:', error);
        if (error.status === 400) {
          alert('Invalid username or password');
        } else {
          alert('Server error. Please try again later.');
        }
      }
    );
  }
}
