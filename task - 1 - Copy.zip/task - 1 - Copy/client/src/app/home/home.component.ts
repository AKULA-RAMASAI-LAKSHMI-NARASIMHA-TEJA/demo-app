import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent {
  constructor(private router: Router) {}

  onLogout() {
    // Perform any logout logic here, such as clearing session storage or cookies
    alert('Logged out successfully');
    this.router.navigate(['']); // Redirect to the login page
  }
}